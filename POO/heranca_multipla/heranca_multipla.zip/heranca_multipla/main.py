from smartphone import Smartphone

smartphone = Smartphone('Pocophone F1')
smartphone.conetar()
smartphone.desligar()
smartphone.ligar()
smartphone.conetar()
smartphone.conetar()
smartphone.conetar()
smartphone.desligar()
smartphone.conetar()
smartphone.desconectar()
smartphone.desconectar()
